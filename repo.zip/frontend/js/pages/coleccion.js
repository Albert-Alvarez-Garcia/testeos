/********************************************************************************
 * [MODULE]: MI COLECCIÓN (coleccion.js)
 * [DESCRIPTION]: Vista de toda la colección del usuario, agrupada por carta.
 *   - Filtros (nombre, tipo, subtipo, contenedor, rareza, set, foil), orden y paginación
 *   - Detalle por carta con todos sus artes y los contenedores/huecos donde están
 *   - Informe, exportar/importar JSON e impresión
 * [API]: GET /collection, /collection/summary, /collection/export, POST /collection/import
 ********************************************************************************/
(() => {
    'use strict';

    const API_BASE_URL = '/api';
    const NOCAPI = 'public/assets/nocapi.png';

    const DEFAULTS = {
        name: '', type: '', subtype: '', container: '', rarity: '', set: '', foil: '',
        sort: 'name', order: 'asc', page: 1, size: 24
    };
    const SORT_KEYS = ['name', 'quantity', 'recent', 'type', 'rarity', 'printings'];
    const PAGE_SIZES = [12, 24, 48, 96];
    // Clave en la URL de cada filtro: así la página se puede recargar o compartir sin perder la vista
    const URL_KEYS = {
        name: 'q', type: 'tipo', subtype: 'subtipo', container: 'cont', rarity: 'rareza', set: 'set',
        foil: 'foil', sort: 'orden', order: 'sentido', page: 'pag', size: 'por'
    };

    const RARITY = { common: 'Común', uncommon: 'Poco común', rare: 'Rara', mythic: 'Mítica', special: 'Especial', bonus: 'Bonus' };
    const CONTAINER_TYPES = {
        binder_s: 'Binder pequeño', binder_m: 'Binder mediano', binder_xl: 'Binder grande', binder_l: 'Binder grande',
        binder: 'Binder', deck: 'Mazo', box: 'Caja'
    };
    const COND_ALIASES = {
        'near mint': 'NM', nm: 'NM', mint: 'M', m: 'M', 'lightly played': 'LP', lp: 'LP',
        'moderately played': 'MP', mp: 'MP', 'heavily played': 'HP', hp: 'HP', damaged: 'DMG', dmg: 'DMG'
    };
    const COND_NAMES = { M: 'Mint', NM: 'Near Mint', LP: 'Lightly Played', MP: 'Moderately Played', HP: 'Heavily Played', DMG: 'Damaged' };
    const COND_ORDER = ['M', 'NM', 'LP', 'MP', 'HP', 'DMG'];

    const $ = (id) => document.getElementById(id);
    const els = {
        grid: $('cardGrid'), pager: $('pager'), info: $('resultsInfo'), status: $('statusBox'), banner: $('containerBanner'),
        name: $('fName'), type: $('fType'), subtype: $('fSubtype'), container: $('fContainer'), rarity: $('fRarity'),
        set: $('fSet'), foil: $('fFoil'), sort: $('fSort'), order: $('orderBtn'), size: $('fPageSize'), reset: $('resetBtn'),
        form: $('filtersForm'), toggle: $('filtersToggle'), detail: $('detailDialog'), detailBody: $('detailBody'),
        importDlg: $('importDialog'), importBody: $('importBody'), printDlg: $('printDialog'), printBody: $('printBody'),
        printReport: $('printReport'), toast: $('toast'), resultsBar: document.querySelector('.results-bar')
    };

    let state = { ...DEFAULTS };
    let lastData = null;
    let requestSeq = 0;
    let taxonomy = {};
    let containersById = new Map();
    let detailItem = null;
    let detailIdx = 0;
    let reportReady = false;
    let originalTitle = document.title;

    // ------------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------------
    const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
    const fmt = (n) => Number(n || 0).toLocaleString('es-ES');
    const plural = (n, one, many) => `${fmt(n)} ${n === 1 ? one : many}`;
    const imgOf = (p) => (p && p.image_uri) || NOCAPI;
    const rarityLabel = (r) => RARITY[r] || (r ? r.charAt(0).toUpperCase() + r.slice(1) : 'Sin rareza');
    const rarityClass = (r) => (['common', 'uncommon', 'rare', 'mythic'].includes(r) ? r : 'other');
    const typeLabel = (t) => CONTAINER_TYPES[String(t || '').toLowerCase()] || t || 'Contenedor';
    const setCode = (p) => String(p.set_code || '').toUpperCase();
    const setShort = (p) => `${setCode(p)} #${p.collector_number}`;
    const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Usuario guardado en el navegador (solo para mostrarlo y comprobar que hay sesión; no se envía al servidor)
    function getUsername() {
        let username = null;
        try {
            const userData = JSON.parse(localStorage.getItem('cardbinder_user')) ||
                             JSON.parse(localStorage.getItem('user_session'));
            if (userData && userData.username) username = userData.username;
        } catch (e) {
            console.error('Error leyendo usuario:', e);
        }
        return username;
    }

    // La identidad viaja en la cookie de sesión; no hace falta cabecera
    function getAuthHeader() {
        return {};
    }

    function today() {
        const d = new Date();
        const p = (n) => String(n).padStart(2, '0');
        return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
    }

    function debounce(fn, ms) {
        let t;
        return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
    }

    class ApiError extends Error {
        constructor(message, status) { super(message); this.status = status; }
    }

    function detailToText(detail) {
        if (!detail) return '';
        if (Array.isArray(detail)) return detail.map((d) => d.msg || JSON.stringify(d)).join(', ');
        return String(detail);
    }

    // Llamada a la API con la cabecera de usuario. raw=true devuelve la respuesta sin leer el cuerpo.
    async function api(path, { method = 'GET', params, body, raw = false } = {}) {
        const url = new URL(API_BASE_URL + path);
        if (params) {
            for (const [k, v] of Object.entries(params)) {
                if (v !== '' && v !== null && v !== undefined) url.searchParams.set(k, v);
            }
        }
        let res;
        try {
            res = await fetch(url, {
                method,
                headers: {
                    Accept: 'application/json',
                    ...(body ? { 'Content-Type': 'application/json' } : {}),
                    ...getAuthHeader()
                },
                body: body ? JSON.stringify(body) : undefined
            });
        } catch (e) {
            throw new ApiError('No se pudo conectar con el servidor. Comprueba que la API está en marcha.', 0);
        }
        if (res.status === 401) {
            location.href = 'login.html';
            throw new ApiError('Sesión no válida.', 401);
        }
        if (!res.ok) {
            let data = null;
            try { data = await res.json(); } catch (e) { /* sin cuerpo JSON */ }
            throw new ApiError(detailToText(data && data.detail) || `Error ${res.status} del servidor.`, res.status);
        }
        if (raw) return { res };
        return { data: await res.json(), res };
    }

    function toast(message, kind = 'ok') {
        els.toast.textContent = message;
        els.toast.className = 'toast' + (kind === 'error' ? ' error' : '');
        els.toast.hidden = false;
        clearTimeout(toast.timer);
        toast.timer = setTimeout(() => { els.toast.hidden = true; }, kind === 'error' ? 6500 : 3500);
    }

    // Estados de la tarjeta: la BBDD mezcla "NM" y "Near Mint"; aquí se unifican al mostrarlos
    function normCondition(c) {
        const key = String(c || '').trim().toLowerCase();
        return COND_ALIASES[key] || (c && c !== '—' ? String(c) : '—');
    }
    function conditionEntries(map) {
        const out = {};
        for (const [k, q] of Object.entries(map || {})) {
            const n = normCondition(k);
            out[n] = (out[n] || 0) + q;
        }
        const idx = (c) => { const i = COND_ORDER.indexOf(c); return i < 0 ? 99 : i; };
        return Object.entries(out).sort((a, b) => idx(a[0]) - idx(b[0]));
    }

    // Une números consecutivos: [1,2,3,5] -> "1–3, 5"
    function ranges(nums) {
        const list = [...new Set(nums)].sort((a, b) => a - b);
        if (!list.length) return '';
        const out = [];
        let start = list[0], prev = list[0];
        for (let i = 1; i <= list.length; i++) {
            const n = list[i];
            if (n === prev + 1) { prev = n; continue; }
            out.push(start === prev ? `${start}` : `${start}–${prev}`);
            start = n; prev = n;
        }
        return out.join(', ');
    }

    // Dónde está cada copia, según el tipo de contenedor
    function positionGroups(type, positions) {
        const t = String(type || '').toLowerCase();
        const groups = new Map();
        for (const p of positions || []) {
            let key, label;
            if (t.includes('binder')) { key = `p${p.page}`; label = `Pág. ${p.page} · huecos`; }
            else if (t === 'deck') { key = p.section === 'sideboard' ? 's' : 'm'; label = p.section === 'sideboard' ? 'Banquillo' : 'Mazo'; }
            else { key = 'x'; label = 'Huecos'; }
            if (!groups.has(key)) groups.set(key, { label, slots: [] });
            groups.get(key).slots.push(p.slot);
        }
        return [...groups.values()].map((g) => `${g.label} ${ranges(g.slots)}`);
    }

    // ------------------------------------------------------------------------
    // Estado <-> URL <-> controles
    // ------------------------------------------------------------------------
    function readUrl() {
        const p = new URLSearchParams(location.search);
        const s = { ...DEFAULTS };
        for (const [k, q] of Object.entries(URL_KEYS)) if (p.has(q)) s[k] = p.get(q);
        s.page = Math.max(1, parseInt(s.page, 10) || 1);
        s.size = PAGE_SIZES.includes(Number(s.size)) ? Number(s.size) : DEFAULTS.size;
        if (!SORT_KEYS.includes(s.sort)) s.sort = DEFAULTS.sort;
        if (!['asc', 'desc'].includes(s.order)) s.order = DEFAULTS.order;
        if (!['', 'true', 'false'].includes(s.foil)) s.foil = '';
        return s;
    }

    function writeUrl() {
        const p = new URLSearchParams();
        for (const [k, q] of Object.entries(URL_KEYS)) {
            if (String(state[k]) !== String(DEFAULTS[k])) p.set(q, state[k]);
        }
        const qs = p.toString();
        try { history.replaceState(null, '', location.pathname + (qs ? `?${qs}` : '')); } catch (e) { /* file:// */ }
    }

    function fillSubtypes() {
        const subs = taxonomy[state.type] || [];
        els.subtype.innerHTML = '<option value="">Cualquier subtipo</option>' +
            subs.map((s) => `<option value="${esc(s)}">${esc(s)}</option>`).join('');
        els.subtype.disabled = subs.length === 0;
        if (!subs.includes(state.subtype)) state.subtype = '';
        els.subtype.value = state.subtype;
    }

    function updateOrderButton() {
        const asc = state.order === 'asc';
        els.order.textContent = asc ? '↑' : '↓';
        els.order.setAttribute('aria-label', asc ? 'Orden ascendente' : 'Orden descendente');
        els.order.title = asc ? 'Orden ascendente (pulsa para invertir)' : 'Orden descendente (pulsa para invertir)';
    }

    function applyStateToControls() {
        els.name.value = state.name;
        if (state.type && ![...els.type.options].some((o) => o.value === state.type)) state.type = '';
        els.type.value = state.type;
        fillSubtypes();
        if (state.container && ![...els.container.options].some((o) => o.value === state.container)) state.container = '';
        els.container.value = state.container;
        els.rarity.value = state.rarity;
        els.set.value = state.set;
        els.foil.value = state.foil;
        els.sort.value = state.sort;
        els.size.value = String(state.size);
        updateOrderButton();
        updateToggle();
    }

    function queryParams(extra = {}) {
        return {
            name: state.name.trim(), type_line: state.type, subtype: state.subtype, container_id: state.container,
            rarity: state.rarity, set: state.set.trim(), foil: state.foil, sort: state.sort, order: state.order, ...extra
        };
    }

    function describeFilters() {
        const parts = [];
        if (state.name.trim()) parts.push(`nombre «${state.name.trim()}»`);
        if (state.type) parts.push(`tipo ${state.type}`);
        if (state.subtype) parts.push(`subtipo ${state.subtype}`);
        if (state.container) parts.push(`contenedor «${(containersById.get(state.container) || {}).name || '?'}»`);
        if (state.rarity) parts.push(`rareza ${rarityLabel(state.rarity).toLowerCase()}`);
        if (state.set.trim()) parts.push(`set «${state.set.trim()}»`);
        if (state.foil === 'true') parts.push('solo foil');
        if (state.foil === 'false') parts.push('sin foil');
        return parts;
    }

    // En móvil los filtros secundarios están plegados: el botón indica cuántos hay activos
    function updateToggle() {
        const active = describeFilters().length - (state.name.trim() ? 1 : 0);
        const open = els.form.classList.contains('open');
        els.toggle.textContent = (open ? 'Menos filtros' : 'Más filtros') + (active > 0 ? ` (${active} activos)` : '');
        els.toggle.setAttribute('aria-expanded', String(open));
    }

    function refresh({ resetPage = true } = {}) {
        if (resetPage) state.page = 1;
        updateToggle();
        writeUrl();
        loadCollection();
    }

    // ------------------------------------------------------------------------
    // Carga de datos
    // ------------------------------------------------------------------------
    async function loadTaxonomy() {
        try {
            const { data } = await api('/cards/types-taxonomy');
            taxonomy = data || {};
        } catch (e) {
            taxonomy = {};
        }
        els.type.innerHTML = '<option value="">Cualquier tipo</option>' +
            Object.keys(taxonomy).sort((a, b) => a.localeCompare(b, 'es'))
                .map((t) => `<option value="${esc(t)}">${esc(t)}</option>`).join('');
    }

    async function loadContainers() {
        try {
            const { data } = await api('/containers/');
            containersById = new Map((data || []).map((c) => [String(c.id), c]));
            els.container.innerHTML = '<option value="">Todos los contenedores</option>' +
                (data || []).map((c) => `<option value="${esc(c.id)}">${esc(c.name || 'Sin nombre')} (${esc(typeLabel(c.type))})</option>`).join('');
        } catch (e) {
            containersById = new Map();
        }
    }

    async function loadSummary() {
        try {
            const { data } = await api('/collection/summary');
            renderSummary(data);
        } catch (e) {
            $('reportBody').innerHTML = `<p class="muted">No se pudo cargar el informe: ${esc(e.message)}</p>`;
        }
    }

    async function loadCollection() {
        const seq = ++requestSeq;
        els.grid.setAttribute('aria-busy', 'true');
        try {
            const { data } = await api('/collection', { params: queryParams({ page: state.page, page_size: state.size }) });
            if (seq !== requestSeq) return;
            // La página pedida ya no existe (p. ej. tras borrar cartas): se vuelve a la última
            if (data.items.length === 0 && data.total > 0 && state.page > data.total_pages) {
                state.page = data.total_pages;
                writeUrl();
                return loadCollection();
            }
            lastData = data;
            renderList(data);
        } catch (e) {
            if (seq !== requestSeq) return;
            lastData = null;
            els.grid.innerHTML = '';
            els.pager.innerHTML = '';
            els.banner.hidden = true;
            els.info.textContent = 'No se pudo cargar la colección.';
            showStatus({
                error: true, title: 'No se pudo cargar la colección', text: e.message,
                actions: [{ id: 'retry', label: 'Reintentar' }]
            });
        } finally {
            if (seq === requestSeq) els.grid.setAttribute('aria-busy', 'false');
        }
    }

    // ------------------------------------------------------------------------
    // Pintado: totales e informe
    // ------------------------------------------------------------------------
    function renderSummary(s) {
        const t = s.totals;
        $('statCopies').textContent = fmt(t.total_copies);
        $('statCards').textContent = fmt(t.unique_cards);
        $('statPrintings').textContent = fmt(t.unique_printings);
        $('statFoil').textContent = fmt(t.foil_copies);
        $('statContainers').textContent = fmt(t.containers);

        const totalRar = s.by_rarity.reduce((n, r) => n + r.copies, 0) || 1;
        const order = ['common', 'uncommon', 'rare', 'mythic'];
        const known = order.map((k) => s.by_rarity.find((r) => r.rarity === k)).filter(Boolean);
        const otherCopies = s.by_rarity.filter((r) => !order.includes(r.rarity)).reduce((n, r) => n + r.copies, 0);
        const segs = [...known.map((r) => ({ cls: r.rarity, label: rarityLabel(r.rarity), copies: r.copies }))];
        if (otherCopies) segs.push({ cls: 'other', label: 'Otras', copies: otherCopies });

        const rarityCol = `
            <div class="report-col">
                <h3>Por rareza</h3>
                <div class="bar rarity-bar" role="img" aria-label="Reparto de copias por rareza">
                    ${segs.map((g) => `<span class="${g.cls}" style="width:${(g.copies / totalRar * 100).toFixed(2)}%"></span>`).join('')}
                </div>
                <ul>${segs.map((g) => `
                    <li class="row-between"><span><span class="dot ${g.cls}"></span>${esc(g.label)}</span>
                    <span>${fmt(g.copies)} <span class="muted">(${Math.round(g.copies / totalRar * 100)}%)</span></span></li>`).join('')}
                </ul>
            </div>`;

        const containerCol = `
            <div class="report-col">
                <h3>Contenedores</h3>
                ${s.by_container.length ? `<ul>${s.by_container.map((c) => {
                    const used = c.total_slots - c.free_slots;
                    const pct = c.total_slots ? Math.round(used / c.total_slots * 100) : 0;
                    return `<li>
                        <div class="row-between"><span>${esc(c.name)} <span class="muted">· ${esc(typeLabel(c.type))}</span></span>
                        <span>${fmt(c.copies)} ${c.copies === 1 ? 'copia' : 'copias'}</span></div>
                        <div class="bar" role="img" aria-label="${pct}% de huecos ocupados"><span style="width:${pct}%"></span></div>
                        <span class="muted">${fmt(used)} de ${fmt(c.total_slots)} huecos ocupados (${pct}%)</span></li>`;
                }).join('')}</ul>` : '<p class="muted">Todavía no tienes contenedores.</p>'}
            </div>`;

        const freeTotal = s.by_container.reduce((n, c) => n + c.free_slots, 0);
        const insightCol = `
            <div class="report-col">
                <h3>Repetidas y artes</h3>
                <ul>
                    <li class="row-between"><span>Cartas con copias repetidas</span><b>${fmt(s.insights.cards_with_duplicates)}</b></li>
                    <li class="row-between"><span>Cartas con varios artes</span><b>${fmt(s.insights.cards_with_several_arts)}</b></li>
                    <li class="row-between"><span>Huecos libres en total</span><b>${fmt(freeTotal)}</b></li>
                </ul>
            </div>`;
        $('reportBody').innerHTML = rarityCol + containerCol + insightCol;
    }

    // ------------------------------------------------------------------------
    // Pintado: lista de cartas
    // ------------------------------------------------------------------------
    function tileHtml(item, idx) {
        const covers = item.printings.slice(0, 3);
        const cover = covers[0];
        const under = covers.slice(1)
            .map((p, i) => `<img class="under u${i + 1}" src="${esc(imgOf(p))}" alt="" loading="lazy" decoding="async" aria-hidden="true">`).join('');
        const hasFoil = item.printings.some((p) => p.foil_copies > 0);
        const shown = item.containers.slice(0, 2);
        const chips = shown.map((c) => `<span class="chip" title="${esc(c.name)}">${esc(c.name)} <b>×${c.quantity}</b></span>`).join('') +
            (item.containers.length > 2 ? `<span class="chip" title="${esc(item.containers.slice(2).map((c) => c.name).join(', '))}">+${item.containers.length - 2}</span>` : '');
        const arts = item.printings_count > 1 ? `${item.printings_count} artes distintos` : setShort(cover);
        const label = `${item.name}: ${plural(item.total_copies, 'copia', 'copias')}, ${plural(item.printings_count, 'arte', 'artes')}. Abrir detalle`;
        return `<li><button type="button" class="card-tile" data-idx="${idx}" aria-label="${esc(label)}">
            <span class="art">${under}<img class="cover" src="${esc(imgOf(cover))}" alt="" loading="lazy" decoding="async">
                <span class="seal" aria-hidden="true">×${item.total_copies}</span>
            </span>
            <span class="tile-name">${esc(item.name)}</span>
            <span class="tile-type">${esc(item.type_line)}</span>
            <span class="tile-arts">${esc(arts)}${hasFoil ? ' <span class="foil-tag" title="Incluye copias foil">✦ foil</span>' : ''}</span>
            <span class="chips">${chips}</span>
        </button></li>`;
    }

    function showStatus({ title, text, actions = [], error = false, link = null }) {
        els.status.className = 'status-box' + (error ? ' error' : '');
        els.status.innerHTML = `<h2>${esc(title)}</h2><p>${esc(text)}</p>
            ${actions.map((a) => `<button type="button" class="col-btn" data-action="${a.id}">${esc(a.label)}</button>`).join(' ')}
            ${link ? `<a class="col-btn primary" style="display:inline-block;text-decoration:none" href="${esc(link.href)}">${esc(link.label)}</a>` : ''}`;
        els.status.hidden = false;
    }

    function renderList(data) {
        const filters = describeFilters();
        els.status.hidden = true;

        if (state.container) {
            const c = containersById.get(state.container);
            els.banner.innerHTML = `Mostrando solo las copias que están en «${esc(c ? c.name : 'este contenedor')}». ` +
                'Las cantidades de cada carta cuentan únicamente ese contenedor. ' +
                '<button type="button" class="col-btn quiet" data-action="all-containers">Ver todos los contenedores</button>';
            els.banner.hidden = false;
        } else {
            els.banner.hidden = true;
        }

        if (data.total === 0) {
            els.grid.innerHTML = '';
            els.pager.innerHTML = '';
            els.info.textContent = '0 cartas';
            if (filters.length) {
                showStatus({
                    title: 'Ninguna carta coincide con estos filtros',
                    text: 'Prueba con menos filtros o con otro nombre.',
                    actions: [{ id: 'reset', label: 'Limpiar filtros' }]
                });
            } else {
                showStatus({
                    title: 'Tu colección está vacía',
                    text: 'Las cartas aparecen aquí cuando las añades a un contenedor.',
                    link: { href: 'visor-admin-25d.html', label: 'Añadir cartas' }
                });
            }
            return;
        }

        els.grid.innerHTML = data.items.map(tileHtml).join('');
        const from = (data.page - 1) * data.page_size + 1;
        const to = from + data.items.length - 1;
        els.info.textContent = `Mostrando ${fmt(from)}–${fmt(to)} de ${plural(data.total, 'carta', 'cartas')}` +
            (filters.length ? ' con los filtros aplicados' : '');
        renderPager(data.page, data.total_pages);
    }

    function renderPager(page, totalPages) {
        if (totalPages <= 1) { els.pager.innerHTML = ''; return; }
        const nums = [...new Set([1, totalPages, page - 1, page, page + 1])]
            .filter((n) => n >= 1 && n <= totalPages).sort((a, b) => a - b);
        let html = `<button type="button" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>‹ Anterior</button>`;
        let prev = 0;
        for (const n of nums) {
            if (n - prev > 1) html += '<span class="gap" aria-hidden="true">…</span>';
            html += `<button type="button" data-page="${n}" ${n === page ? 'aria-current="page"' : ''} aria-label="Página ${n}">${n}</button>`;
            prev = n;
        }
        html += `<button type="button" data-page="${page + 1}" ${page >= totalPages ? 'disabled' : ''}>Siguiente ›</button>`;
        els.pager.innerHTML = html;
    }

    // ------------------------------------------------------------------------
    // Detalle de una carta
    // ------------------------------------------------------------------------
    function openDetail(item) {
        detailItem = item;
        detailIdx = 0;
        renderDetail();
        els.detail.showModal();
    }

    function renderDetail(focusThumb = false) {
        const item = detailItem;
        const p = item.printings[detailIdx];
        const thumbs = item.printings.length > 1 ? `
            <div class="thumbs" role="group" aria-label="Artes de esta carta">
                ${item.printings.map((pr, i) => `<button type="button" class="thumb" data-i="${i}" aria-pressed="${i === detailIdx}"
                    title="${esc(pr.set_name)} (${esc(setShort(pr))}) · ${pr.quantity} ${pr.quantity === 1 ? 'copia' : 'copias'}">
                    <img src="${esc(imgOf(pr))}" alt="Arte de ${esc(pr.set_name)}"><span class="q">${pr.quantity}</span></button>`).join('')}
            </div>` : '';

        const conds = conditionEntries(p.conditions)
            .map(([c, q]) => `<span class="chip" title="${esc(COND_NAMES[c] || c)}">${esc(c)} <b>×${q}</b></span>`).join(' ');

        const locs = p.locations.map((l) => {
            const groups = positionGroups(l.type, l.positions);
            const more = l.positions_total > l.positions.length ? ` (y ${l.positions_total - l.positions.length} más)` : '';
            return `<li><div class="loc-head">
                    <a href="visor-containers.html?container_id=${encodeURIComponent(l.container_id)}">${esc(l.name)}</a>
                    <span class="loc-type">${esc(typeLabel(l.type))} · ${plural(l.quantity, 'copia', 'copias')}</span></div>
                ${groups.length ? `<p class="loc-pos">${esc(groups.join(' · '))}${more}</p>` : ''}</li>`;
        }).join('');

        els.detailBody.innerHTML = `
            <div class="detail-body">
                <div class="detail-art">
                    <img src="${esc(imgOf(p))}" alt="${esc(item.name)} — ${esc(p.set_name)}">
                    ${thumbs}
                </div>
                <div class="detail-info">
                    <h2 id="detailTitle">${esc(item.name)}</h2>
                    ${item.mana_cost ? `<div class="mana">${esc(item.mana_cost)}</div>` : ''}
                    <div class="typeline">${esc(item.type_line)}</div>
                    ${item.oracle_text ? `<p class="oracle">${esc(item.oracle_text)}</p>` : ''}
                    <p class="totals-line"><strong>${plural(item.total_copies, 'copia', 'copias')}</strong> en
                        ${plural(item.containers.length, 'contenedor', 'contenedores')}
                        · ${plural(item.printings_count, 'arte', 'artes')}</p>
                    <div class="print-panel">
                        <h3>${esc(p.set_name)}</h3>
                        <div class="facts">
                            <span>Código: <b>${esc(setCode(p))} #${esc(p.collector_number)}</b></span>
                            <span><span class="dot ${rarityClass(p.rarity)}"></span>${esc(rarityLabel(p.rarity))}</span>
                            <span>Copias de este arte: <b>${p.quantity}</b></span>
                            <span>Foil: <b>${p.foil_copies}</b></span>
                        </div>
                        <div class="chips" style="margin-bottom:12px" aria-label="Estado de las copias">${conds}</div>
                        <ul class="loc-list">${locs}</ul>
                    </div>
                </div>
            </div>`;
        if (focusThumb) {
            const t = els.detailBody.querySelector(`.thumb[data-i="${detailIdx}"]`);
            if (t) t.focus();
        }
    }

    // ------------------------------------------------------------------------
    // Exportar
    // ------------------------------------------------------------------------
    function download(blob, filename) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = filename;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 2000);
    }

    // Exportar CSV (se genera en el navegador a partir de la exportación JSON)
    function csvCell(v) {
        if (v === null || v === undefined) return '';
        let s = typeof v === 'object' ? JSON.stringify(v) : String(v);
        if (typeof v === 'string' && /^[=+\-@\t\r]/.test(s)) s = "'" + s;   // evita inyección de fórmulas en hojas de cálculo
        return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }

    function flattenRow(o, prefix, out) {
        for (const [k, v] of Object.entries(o)) {
            const key = prefix ? prefix + '.' + k : k;
            if (v && typeof v === 'object' && !Array.isArray(v)) flattenRow(v, key, out);
            else out[key] = Array.isArray(v) ? v.join(' | ') : v;
        }
        return out;
    }

    async function exportCsv() {
        const btn = $('exportCsvBtn');
        btn.disabled = true;
        try {
            const { res } = await api('/collection/export', { raw: true });
            const data = await res.json();
            const rows = (data.copies || []).map((c) => flattenRow(c, '', {}));
            if (!rows.length) throw new Error('No hay cartas que exportar');
            const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))];
            const lines = [cols.map(csvCell).join(',')].concat(rows.map((r) => cols.map((c) => csvCell(r[c])).join(',')));
            download(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }), `coleccion-${today()}.csv`);
            toast('Colección exportada en CSV.');
        } catch (e) {
            toast(`No se pudo exportar: ${e.message}`, 'error');
        } finally {
            btn.disabled = false;
        }
    }

    async function exportJson() {
        const btn = $('exportBtn');
        btn.disabled = true;
        try {
            const { res } = await api('/collection/export', { raw: true });
            download(await res.blob(), `coleccion-${today()}.json`);
            toast('Colección exportada.');
        } catch (e) {
            toast(`No se pudo exportar: ${e.message}`, 'error');
        } finally {
            btn.disabled = false;
        }
    }

    // ------------------------------------------------------------------------
    // Importar (primero se simula; solo se guarda tras confirmar)
    // ------------------------------------------------------------------------
    let importPayload = null;

    function openImport() {
        importPayload = null;
        renderImportStart();
        els.importDlg.showModal();
    }

    function renderImportStart(errorMsg) {
        els.importBody.innerHTML = `
            <p class="dlg-p">Elige un archivo JSON exportado desde Mi Colección. Antes de guardar nada verás un resumen de lo que se importaría.</p>
            <label class="file-drop"><input type="file" id="importFile" accept="application/json,.json"><span>Elegir archivo .json</span></label>
            ${errorMsg ? `<p class="err" role="alert">${esc(errorMsg)}</p>` : ''}`;
        $('importFile').addEventListener('change', onImportFile);
    }

    async function onImportFile(e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        if (file.size > 30 * 1024 * 1024) return renderImportStart('El archivo supera los 30 MB.');
        let json;
        try { json = JSON.parse(await file.text()); } catch (err) { return renderImportStart('El archivo no es un JSON válido.'); }
        if (!json || !Array.isArray(json.copies)) {
            return renderImportStart('El archivo no incluye la lista de copias. ¿Es una exportación de Mi Colección?');
        }
        if (!json.copies.length) return renderImportStart('El archivo no contiene copias.');

        importPayload = { format: json.format, version: json.version, copies: json.copies };
        els.importBody.innerHTML = '<p class="dlg-p" role="status">Comprobando el archivo…</p>';
        try {
            const { data } = await api('/collection/import', { method: 'POST', params: { dry_run: 'true' }, body: importPayload });
            renderImportPreview(data, file.name);
        } catch (err) {
            renderImportStart(err.message);
        }
    }

    function renderImportPreview(r, fileName) {
        const rows = r.containers.map((c) => `<tr><td>${esc(c.container)} <span class="muted">(${esc(typeLabel(c.type))})</span></td>
            <td class="num">${c.to_import} de ${c.requested}</td><td class="num">${c.free_slots}</td></tr>`).join('');
        const reasons = r.error_summary.map((x) => `<li>${x.count} × ${esc(x.reason)}</li>`).join('');
        els.importBody.innerHTML = `
            <p class="dlg-p"><strong>${esc(fileName)}</strong></p>
            <div class="kv"><span>En el archivo: <b>${fmt(r.total)}</b></span><span>Se importarían: <b>${fmt(r.importable)}</b></span><span>Se omitirían: <b>${fmt(r.skipped)}</b></span></div>
            <p class="warn">Importar <strong>añade</strong> copias nuevas y no comprueba si ya las tienes. Si el archivo viene de esta misma cuenta, las copias quedarán duplicadas.</p>
            ${rows ? `<table class="mini-table"><thead><tr><th>Contenedor</th><th class="num">Se importan</th><th class="num">Huecos libres</th></tr></thead><tbody>${rows}</tbody></table>` : ''}
            ${reasons ? `<p class="dlg-p">Copias que se omitirían:</p><ul class="reasons">${reasons}</ul>` : ''}
            <div class="dlg-actions">
                <button type="button" class="col-btn" id="importBack">Elegir otro archivo</button>
                <button type="button" class="col-btn primary" id="importGo" ${r.importable ? '' : 'disabled'}>Importar ${plural(r.importable, 'copia', 'copias')}</button>
            </div>
            <p class="err" id="importErr" role="alert" hidden></p>`;
        $('importBack').addEventListener('click', () => renderImportStart());
        $('importGo').addEventListener('click', confirmImport);
    }

    async function confirmImport() {
        const go = $('importGo');
        go.disabled = true;
        go.textContent = 'Importando…';
        try {
            const { data } = await api('/collection/import', { method: 'POST', params: { dry_run: 'false' }, body: importPayload });
            els.importDlg.close();
            toast(`Se importaron ${plural(data.imported, 'copia', 'copias')}` + (data.skipped ? ` y se omitieron ${data.skipped}.` : '.'));
            importPayload = null;
            await Promise.all([loadSummary(), loadCollection()]);
        } catch (e) {
            const box = $('importErr');
            box.textContent = e.message;
            box.hidden = false;
            go.disabled = false;
            go.textContent = 'Reintentar importación';
        }
    }

    // ------------------------------------------------------------------------
    // Imprimir informe
    // ------------------------------------------------------------------------
    function openPrint() {
        const filters = describeFilters();
        els.printBody.innerHTML = `
            <p class="dlg-p">Se imprimirá una lista con todas las cartas que coinciden con los filtros actuales, no solo esta página
                (${esc(filters.length ? filters.join(', ') : 'sin filtros')}), con el contenedor y los huecos de cada copia.</p>
            <label class="check"><input type="checkbox" id="printThumbs"> Incluir miniaturas (gasta más tinta)</label>
            <div id="printProgress" aria-live="polite"></div>
            <div class="dlg-actions">
                <button type="button" class="col-btn" data-close>Cancelar</button>
                <button type="button" class="col-btn primary" id="printGo">Preparar e imprimir</button>
            </div>`;
        $('printGo').addEventListener('click', runPrint);
        els.printDlg.showModal();
    }

    async function runPrint() {
        const go = $('printGo');
        const thumbs = $('printThumbs').checked;
        const progress = $('printProgress');
        go.disabled = true;
        try {
            const items = [];
            let page = 1, totalPages = 1;
            do {
                progress.innerHTML = `<div class="progress"><span style="width:${Math.round((page - 1) / totalPages * 100)}%"></span></div>
                    <span class="muted">Preparando… página ${page} de ${totalPages}</span>`;
                const { data } = await api('/collection', { params: queryParams({ page, page_size: 200 }) });
                items.push(...data.items);
                totalPages = Math.max(1, data.total_pages);
                page++;
            } while (page <= totalPages);

            if (!items.length) {
                progress.innerHTML = '<p class="err">No hay cartas que imprimir con los filtros actuales.</p>';
                go.disabled = false;
                return;
            }
            renderPrintReport(items, { thumbs, scope: 'Todas las cartas que coinciden con los filtros' });
            if (thumbs) {
                progress.innerHTML = '<span class="muted">Cargando miniaturas…</span>';
                await waitForImages(els.printReport);
            }
            els.printDlg.close();
            window.print();
        } catch (e) {
            progress.innerHTML = `<p class="err" role="alert">${esc(e.message)}</p>`;
            go.disabled = false;
        }
    }

    function waitForImages(root, timeout = 10000) {
        const pending = [...root.querySelectorAll('img')].filter((i) => !i.complete)
            .map((i) => new Promise((r) => { i.onload = i.onerror = r; }));
        return Promise.race([Promise.all(pending), new Promise((r) => setTimeout(r, timeout))]);
    }

    function renderPrintReport(items, { thumbs = false, scope = '' } = {}) {
        const copies = items.reduce((n, i) => n + i.total_copies, 0);
        const printings = items.reduce((n, i) => n + i.printings.length, 0);
        const filters = describeFilters();
        const user = getUsername();
        const cols = thumbs ? 7 : 6;

        const bodies = items.map((it) => {
            const rows = it.printings.map((p) => {
                const where = p.locations.map((l) => {
                    const g = positionGroups(l.type, l.positions).join('; ');
                    const more = l.positions_total > l.positions.length ? ` (+${l.positions_total - l.positions.length})` : '';
                    return `<div>${esc(l.name)} ×${l.quantity}${g ? ` — ${esc(g)}${more}` : ''}</div>`;
                }).join('');
                const conds = conditionEntries(p.conditions).map(([c, q]) => `${esc(c)} ×${q}`).join(', ');
                return `<tr>
                    ${thumbs ? `<td class="thumb-cell"><img src="${esc(imgOf(p))}" alt="" loading="eager"></td>` : ''}
                    <td>${esc(p.set_name)} <span>(${esc(setShort(p))})</span></td>
                    <td>${esc(rarityLabel(p.rarity))}</td>
                    <td class="num">${p.quantity}</td>
                    <td class="num">${p.foil_copies || '—'}</td>
                    <td>${conds}</td>
                    <td>${where}</td></tr>`;
            }).join('');
            return `<tbody><tr class="pr-head"><th colspan="${cols}">${esc(it.name)}
                <span>${esc(it.type_line)} · ${plural(it.total_copies, 'copia', 'copias')}</span></th></tr>${rows}</tbody>`;
        }).join('');

        els.printReport.innerHTML = `
            <h1 class="pr-title">Mi colección</h1>
            <p class="pr-meta">${esc(new Date().toLocaleDateString('es-ES', { dateStyle: 'long' }))} · Usuario: ${esc(user)}</p>
            <p class="pr-meta">${esc(scope)} (${esc(filters.length ? filters.join(', ') : 'sin filtros')})</p>
            <div class="pr-totals"><span><b>${fmt(items.length)}</b> cartas</span><span><b>${fmt(copies)}</b> copias</span><span><b>${fmt(printings)}</b> artes</span></div>
            <table class="pr-table">
                <thead><tr>${thumbs ? '<th></th>' : ''}<th>Set</th><th>Rareza</th><th class="num">Cant.</th><th class="num">Foil</th><th>Estado</th><th>Ubicación</th></tr></thead>
                ${bodies}
            </table>
            <p class="pr-foot">Generado con Card Binder Pro</p>`;
        reportReady = true;
    }

    // Ctrl+P / menú del navegador: si no hay informe preparado, se imprime la página actual
    window.addEventListener('beforeprint', () => {
        if (!reportReady && lastData && lastData.items.length) {
            renderPrintReport(lastData.items, { thumbs: false, scope: `Página ${lastData.page} de ${lastData.total_pages} de los resultados actuales` });
        }
        originalTitle = document.title;
        document.title = `Coleccion-${today()}`;
        document.body.classList.add('printing');
    });
    window.addEventListener('afterprint', () => {
        document.body.classList.remove('printing');
        document.title = originalTitle;
        els.printReport.innerHTML = '';
        reportReady = false;
    });

    // ------------------------------------------------------------------------
    // Eventos
    // ------------------------------------------------------------------------
    function bindEvents() {
        els.form.addEventListener('submit', (e) => { e.preventDefault(); refresh(); });

        const onText = debounce(() => {
            state.name = els.name.value;
            state.set = els.set.value;
            refresh();
        }, 300);
        els.name.addEventListener('input', onText);
        els.set.addEventListener('input', onText);

        els.type.addEventListener('change', () => { state.type = els.type.value; state.subtype = ''; fillSubtypes(); refresh(); });
        els.subtype.addEventListener('change', () => { state.subtype = els.subtype.value; refresh(); });
        els.container.addEventListener('change', () => { state.container = els.container.value; refresh(); });
        els.rarity.addEventListener('change', () => { state.rarity = els.rarity.value; refresh(); });
        els.foil.addEventListener('change', () => { state.foil = els.foil.value; refresh(); });
        els.sort.addEventListener('change', () => {
            state.sort = els.sort.value;
            // Nombre y tipo de la A a la Z; el resto, de más a menos
            state.order = ['name', 'type'].includes(state.sort) ? 'asc' : 'desc';
            updateOrderButton();
            refresh();
        });
        els.order.addEventListener('click', () => {
            state.order = state.order === 'asc' ? 'desc' : 'asc';
            updateOrderButton();
            refresh();
        });
        els.size.addEventListener('change', () => { state.size = Number(els.size.value); refresh(); });
        els.reset.addEventListener('click', resetFilters);
        els.toggle.addEventListener('click', () => { els.form.classList.toggle('open'); updateToggle(); });

        els.pager.addEventListener('click', (e) => {
            const b = e.target.closest('button[data-page]');
            if (!b || b.disabled || b.hasAttribute('aria-current')) return;
            state.page = Number(b.dataset.page);
            refresh({ resetPage: false });
            els.resultsBar.scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' });
        });

        els.grid.addEventListener('click', (e) => {
            const b = e.target.closest('.card-tile');
            if (b && lastData) openDetail(lastData.items[Number(b.dataset.idx)]);
        });
        // Si una imagen falla, se sustituye por la de "carta no disponible" (una sola vez)
        document.addEventListener('error', (e) => {
            const img = e.target;
            if (img && img.tagName === 'IMG' && !img.dataset.fallback) {
                img.dataset.fallback = '1';
                img.src = NOCAPI;
            }
        }, true);

        els.detailBody.addEventListener('click', (e) => {
            const t = e.target.closest('.thumb');
            if (!t) return;
            detailIdx = Number(t.dataset.i);
            renderDetail(true);
        });

        document.addEventListener('click', (e) => {
            const close = e.target.closest('[data-close]');
            if (close) { const d = close.closest('dialog'); if (d) d.close(); return; }
            const act = e.target.closest('[data-action]');
            if (!act) return;
            if (act.dataset.action === 'retry') loadCollection();
            if (act.dataset.action === 'reset') resetFilters();
            if (act.dataset.action === 'all-containers') { state.container = ''; els.container.value = ''; refresh(); }
        });
        // Clic fuera del diálogo (en el fondo) lo cierra
        for (const dlg of document.querySelectorAll('dialog')) {
            dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
        }

        $('exportBtn').addEventListener('click', exportJson);
        const csvBtn = $('exportBtn').cloneNode(false);
        csvBtn.id = 'exportCsvBtn';
        csvBtn.textContent = 'Exportar CSV';
        $('exportBtn').insertAdjacentElement('afterend', csvBtn);
        csvBtn.addEventListener('click', exportCsv);
        $('importBtn').addEventListener('click', openImport);
        $('printBtn').addEventListener('click', openPrint);
    }

    function resetFilters() {
        state = { ...DEFAULTS, size: state.size };
        applyStateToControls();
        refresh();
    }

    // ------------------------------------------------------------------------
    // Arranque
    // ------------------------------------------------------------------------
    async function init() {
        if (!getUsername()) { location.href = 'login.html'; return; }
        state = readUrl();
        bindEvents();
        await Promise.all([loadTaxonomy(), loadContainers()]);
        applyStateToControls();
        writeUrl();
        loadSummary();
        loadCollection();
    }

    init();
})();
