import os
import re
import json
import time
import secrets
from urllib.parse import urlencode, urljoin, urlparse

import bcrypt
import requests
from fastapi import APIRouter, HTTPException, status, Request
from fastapi.responses import RedirectResponse, HTMLResponse, FileResponse
from pydantic import BaseModel, EmailStr, Field
from passlib.context import CryptContext

from backend.services import (
    register_new_user,
    get_user_by_username_or_email,
    get_user_by_username,
    create_42_user,
    update_user_auth_type_to_42,
)

from fastapi import Response
from backend.security import set_session_cookie, clear_session_cookie

router = APIRouter(
    prefix="/api/auth",
    tags=["Authentication"]
)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 42 OAuth2 / OpenID-style public profile endpoints.
FORTYTWO_AUTHORIZE_URL = "https://api.intra.42.fr/oauth/authorize"
FORTYTWO_TOKEN_URL = "https://api.intra.42.fr/oauth/token"
FORTYTWO_ME_URL = "https://api.intra.42.fr/v2/me"

FORTYTWO_CLIENT_ID = os.getenv("FORTYTWO_CLIENT_ID")
FORTYTWO_CLIENT_SECRET = os.getenv("FORTYTWO_CLIENT_SECRET")
FORTYTWO_REDIRECT_URI = os.getenv(
    "FORTYTWO_REDIRECT_URI",
    "http://localhost:8080/api/auth/42/callback"
)


def _redirect_uri(request: Request) -> str:
    """URL de retorno de 42 según el host con el que se entró (localhost, IP del PC...).
    Cada una debe estar dada de alta en la app de 42. PUBLIC_BASE_URL la fija a mano si se define."""
    base = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
    if not base:
        scheme = request.headers.get("x-forwarded-proto") or request.url.scheme
        host = request.headers.get("host") or request.url.netloc
        base = f"{scheme}://{host}"
    return f"{base}/api/auth/42/callback"

# --- AVATARES ---
# La API descarga el avatar de 42 al iniciar sesión y lo sirve ella misma, para que el
# navegador no dependa del CDN (que a veces falla o es bloqueado por ORB al enlazarlo).
# Si quieres que sobrevivan a recrear el contenedor, monta AVATAR_DIR como volumen.
AVATAR_DIR = os.getenv("AVATAR_DIR", "data/avatars")
AVATAR_ALLOWED_HOSTS = {"cdn.intra.42.fr"}  # solo se descarga de aquí (evita SSRF)
AVATAR_MAX_BYTES = 5 * 1024 * 1024
AVATAR_MEDIA_TYPES = {
    "png": "image/png",
    "jpg": "image/jpeg",
    "gif": "image/gif",
    "webp": "image/webp",
}


def _safe_avatar_name(username: str) -> str:
    """Nombre de archivo seguro derivado del usuario (sin rutas ni caracteres raros)."""
    return re.sub(r"[^A-Za-z0-9_-]", "_", username or "")[:64] or "user"


def _detect_image_ext(data: bytes):
    """Devuelve la extensión según la firma real del archivo, o None si no es una imagen soportada."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def _local_avatar_path(username: str):
    """Ruta del avatar ya guardado del usuario (el suyo o uno anterior de 42) o None."""
    safe = _safe_avatar_name(username)
    for ext in AVATAR_MEDIA_TYPES:
        path = os.path.join(AVATAR_DIR, f"{safe}.{ext}")
        if os.path.isfile(path):
            return path
    return None


def _download_avatar(url: str):
    """
    Descarga una imagen comprobando host (solo https y AVATAR_ALLOWED_HOSTS, también en
    cada redirección), tamaño máximo y firma de imagen. Devuelve (bytes, extensión) o None.
    """
    for _ in range(4):  # la URL original + hasta 3 redirecciones
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in AVATAR_ALLOWED_HOSTS:
            return None

        resp = requests.get(
            url,
            headers={"Accept": "image/*,*/*;q=0.8"},
            timeout=8,
            stream=True,
            allow_redirects=False,
        )
        try:
            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get("Location")
                if not location:
                    return None
                url = urljoin(url, location)
                continue

            if resp.status_code != 200:
                return None

            data = b""
            for chunk in resp.iter_content(65536):
                data += chunk
                if len(data) > AVATAR_MAX_BYTES:
                    return None
        finally:
            resp.close()

        ext = _detect_image_ext(data)
        return (data, ext) if ext else None

    return None


def save_avatar_locally(username: str, urls: list):
    """
    Prueba cada URL hasta conseguir una imagen válida y la guarda en AVATAR_DIR.
    Devuelve la ruta pública del avatar en esta API, o None si no se pudo (el login no falla por esto).
    """
    safe = _safe_avatar_name(username)

    try:
        os.makedirs(AVATAR_DIR, exist_ok=True)
    except OSError as e:
        print(f"⚠️ No se pudo crear el directorio de avatares '{AVATAR_DIR}': {e}")
        return None

    for url in urls:
        try:
            result = _download_avatar(url)
        except requests.RequestException as e:
            print(f"⚠️ Error descargando avatar de 42 ({url}): {e}")
            continue

        if not result:
            print(f"⚠️ Avatar de 42 no válido o no disponible: {url}")
            continue

        data, ext = result
        try:
            # Si antes tenía una imagen con otra extensión, se elimina para no servir una antigua
            for other in AVATAR_MEDIA_TYPES:
                if other != ext:
                    stale = os.path.join(AVATAR_DIR, f"{safe}.{other}")
                    if os.path.isfile(stale):
                        os.remove(stale)

            final_path = os.path.join(AVATAR_DIR, f"{safe}.{ext}")
            tmp_path = final_path + ".tmp"
            with open(tmp_path, "wb") as f:
                f.write(data)
            os.replace(tmp_path, final_path)
        except OSError as e:
            print(f"⚠️ No se pudo guardar el avatar de '{safe}': {e}")
            return None

        # ?v=... evita que el navegador use una versión antigua en caché al cambiar la foto
        return f"/api/auth/avatar/{safe}?v={int(time.time())}"

    return None


@router.get("/avatar/{username}")
async def get_avatar(username: str):
    """Sirve el avatar guardado de un usuario (imagen pública de 42) con su Content-Type correcto."""
    safe = _safe_avatar_name(username)
    for ext, media_type in AVATAR_MEDIA_TYPES.items():
        path = os.path.join(AVATAR_DIR, f"{safe}.{ext}")
        if os.path.isfile(path):
            return FileResponse(
                path,
                media_type=media_type,
                headers={"Cache-Control": "public, max-age=3600"},
            )
    raise HTTPException(status_code=404, detail="Avatar no disponible.")



class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=30)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)


class UserLogin(BaseModel):
    username_or_email: str = Field(..., min_length=1, max_length=254)
    password: str = Field(..., min_length=1, max_length=128)


USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]+$")


# Función para encriptar la contraseña
def get_password_hash(password: str) -> str:
    password_bytes = password.encode('utf-8')[:72]
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed.decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    password_bytes = plain_password.encode('utf-8')[:72]
    return bcrypt.checkpw(password_bytes, hashed_password.encode('utf-8'))


@router.post("/register")
async def register_user(user: UserRegister, request: Request, response: Response):
    if not USERNAME_RE.fullmatch(user.username):
        raise HTTPException(status_code=400, detail="El usuario solo puede contener letras, números, punto, guion y guion bajo.")
    if len(str(user.email)) > 254:
        raise HTTPException(status_code=400, detail="El correo es demasiado largo.")
    hashed_pass = get_password_hash(user.password)
    result = register_new_user(user.username, user.email, hashed_pass)

    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El nombre de usuario o el correo electrónico ya están registrados."
        )

    set_session_cookie(response, request, (result.get("user") or {}).get("username") or user.username)
    return {
        "message": "¡Cuenta civil creada con éxito!",
        "user": result["user"]
    }


@router.post("/login")
async def login_user(credentials: UserLogin, request: Request, response: Response):
    user = get_user_by_username_or_email(credentials.username_or_email)

    if not user or not user.get("password_hash"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas. Revisa tu usuario/email y contraseña."
        )

    if not verify_password(credentials.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas. Revisa tu usuario/email y contraseña."
        )

    set_session_cookie(response, request, user["username"])
    return {
        "message": "¡Inicio de sesión exitoso!",
        "username": user["username"],
        "badge": user["badge_type"],
        "redirect": "index.html"
    }


@router.get("/42/login")
async def login_with_42(request: Request):
    """Inicia OAuth2 Authorization Code Flow contra 42."""
    if not FORTYTWO_CLIENT_ID or not FORTYTWO_CLIENT_SECRET:
        raise HTTPException(
            status_code=500,
            detail="Faltan FORTYTWO_CLIENT_ID y/o FORTYTWO_CLIENT_SECRET en el entorno."
        )

    state = secrets.token_urlsafe(32)
    params = {
        "client_id": FORTYTWO_CLIENT_ID,
        "redirect_uri": _redirect_uri(request),
        "response_type": "code",
        "scope": "public",
        "state": state,
    }

    response = RedirectResponse(
        url=f"{FORTYTWO_AUTHORIZE_URL}?{urlencode(params)}",
        status_code=302,
    )
    response.set_cookie(
        key="oauth42_state",
        value=state,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=600,
        path="/api/auth/42",
    )
    return response


@router.get("/42/callback")
async def callback_42(
    request: Request,
    code: str = None,
    state: str = None,
    error: str = None,
):
    """Recibe el callback de 42, identifica al usuario y crea/inicia su cuenta."""
    if error:
        raise HTTPException(status_code=400, detail=f"42 rechazó la autorización: {error}")

    if not code:
        raise HTTPException(status_code=400, detail="42 no devolvió ningún code.")

    expected_state = request.cookies.get("oauth42_state")
    if not state or not expected_state or not secrets.compare_digest(state, expected_state):
        raise HTTPException(
            status_code=400,
            detail="Estado OAuth inválido o caducado. Vuelve a iniciar sesión con 42."
        )

    if not FORTYTWO_CLIENT_ID or not FORTYTWO_CLIENT_SECRET:
        raise HTTPException(status_code=500, detail="Faltan las credenciales OAuth de 42 en el entorno.")

    token_response = requests.post(
        FORTYTWO_TOKEN_URL,
        data={
            "grant_type": "authorization_code",
            "client_id": FORTYTWO_CLIENT_ID,
            "client_secret": FORTYTWO_CLIENT_SECRET,
            "code": code,
            "redirect_uri": _redirect_uri(request),
        },
        headers={"Accept": "application/json"},
        timeout=15,
    )

    if token_response.status_code != 200:
        print("❌ Error token 42:", token_response.status_code, token_response.text)
        raise HTTPException(status_code=502, detail="No se pudo obtener el token de acceso de 42.")

    token_data = token_response.json()
    access_token = token_data.get("access_token")
    if not access_token:
        raise HTTPException(status_code=502, detail="42 no devolvió un access_token válido.")

    me_response = requests.get(
        FORTYTWO_ME_URL,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        },
        timeout=15,
    )

    if me_response.status_code != 200:
        print("❌ Error /v2/me 42:", me_response.status_code, me_response.text)
        raise HTTPException(status_code=502, detail="No se pudo obtener el perfil del usuario de 42.")

    profile = me_response.json()
    username = (profile.get("login") or "").strip()
    email = (profile.get("email") or "").strip().lower()

    if not username:
        raise HTTPException(status_code=502, detail="42 no devolvió el login del usuario.")

    user = get_user_by_username(username)

    if user:
        if user.get("auth_type") == "42":
            final_user = user
        elif email and user.get("email", "").strip().lower() == email:
            final_user = update_user_auth_type_to_42(username)
            if not final_user:
                raise HTTPException(status_code=500, detail="No se pudo vincular la cuenta existente con 42.")
        else:
            # Evita que un login 42 pueda apropiarse de una cuenta local solo por coincidir el alias.
            raise HTTPException(
                status_code=409,
                detail=(
                    f"Ya existe una cuenta local con el usuario '{username}'. "
                    "Inicia sesión con tu contraseña o vincúlala explícitamente con 42."
                ),
            )
    else:
        generated_password = secrets.token_urlsafe(48)
        password_hash = get_password_hash(generated_password)
        if not email:
            email = f"{username}@42.local"

        result = create_42_user(username, email, password_hash)
        if not result["success"]:
            raise HTTPException(
                status_code=400,
                detail="No se pudo crear la cuenta de Card Binder para el usuario de 42.",
            )
        final_user = result["user"]

    # El frontend actual usa localStorage.cardbinder_user. Esta página puente
    # lo escribe en el navegador y vuelve al index sin modificar login.html.
    payload = {
        "username": final_user["username"],
        "badge": final_user.get("badge_type", "42_student"),
    }

    # Imagen de perfil de 42: /v2/me devuelve "image" con "link" y "versions"
    # (en formatos antiguos, "image_url"). El CDN a veces falla con alguna de
    # ellas, así que se envían varias para que el frontend pruebe una tras otra.
    image = profile.get("image")
    candidates = []
    if isinstance(image, dict):
        versions = image.get("versions") or {}
        candidates += [
            versions.get("medium"),
            versions.get("small"),
            versions.get("large"),
            versions.get("micro"),
            image.get("link"),
        ]
    candidates.append(profile.get("image_url"))

    avatar_urls = []
    for url in candidates:
        if isinstance(url, str) and url.startswith("https://") and url not in avatar_urls:
            avatar_urls.append(url)

    existing_avatar = _local_avatar_path(final_user["username"])
    if existing_avatar:
        # Ya tiene avatar guardado (el que eligió o uno anterior de 42): no se vuelve a descargar ni se pisa
        safe_name = _safe_avatar_name(final_user["username"])
        payload["avatar"] = f"/api/auth/avatar/{safe_name}?v={int(os.path.getmtime(existing_avatar))}"
    elif avatar_urls:
        # Primero se intenta descargar y servir el avatar desde esta API. Las URLs de 42
        # quedan como alternativa por si el archivo local desapareciera.
        local_avatar = save_avatar_locally(final_user["username"], avatar_urls)
        if local_avatar:
            payload["avatar"] = local_avatar
            payload["avatar_fallbacks"] = avatar_urls
        else:
            payload["avatar"] = avatar_urls[0]
            if len(avatar_urls) > 1:
                payload["avatar_fallbacks"] = avatar_urls[1:]

    payload_json = json.dumps(payload).replace("<", "\\u003c")

    html = f"""<!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Card Binder — Autenticando con 42</title>
    </head>
    <body>
    <script>
    const user = {payload_json};
    const params = new URLSearchParams();
    params.set('auth42', btoa(unescape(encodeURIComponent(JSON.stringify(user)))));

    window.location.replace('/index.html?' + params.toString());
    </script>

    <p>Autenticación correcta. Redirigiendo...</p>
    </body>
    </html>"""

    response = HTMLResponse(content=html, status_code=200)
    set_session_cookie(response, request, final_user["username"])
    response.delete_cookie("oauth42_state", path="/api/auth/42")
    return response


@router.post("/logout")
async def logout_user(response: Response):
    """Borra la cookie de sesión."""
    clear_session_cookie(response)
    return {"message": "Sesión cerrada."}
