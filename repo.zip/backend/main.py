from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import json
from backend.routers import cards, containers, auth, chat, game, pong_game, achievements, reports, access, profile, social, giphy, stats, dataio

app = FastAPI(title="Card Binder Pro API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- GESTOR DE CONEXIONES WEBSOCKET ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(message))
            except Exception as e:
                print(f"❌ Error enviando mensaje por WS: {e}")

manager = ConnectionManager()

# --- INCLUSIÓN DE ROUTERS ---
app.include_router(cards.router)
app.include_router(giphy.router)
app.include_router(stats.router)
app.include_router(dataio.router)
app.include_router(containers.router)
app.include_router(auth.router)
app.include_router(chat.router)
app.include_router(game.router)
app.include_router(pong_game.router)
app.include_router(achievements.router)
app.include_router(reports.router)
app.include_router(access.router)
app.include_router(profile.router)
app.include_router(social.router)