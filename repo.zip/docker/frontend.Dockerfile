# --- ETAPA 1: Construir la aplicación de React (Pong) ---
FROM node:18-alpine AS builder
WORKDIR /app/pong-client
COPY pong-client/package*.json ./
RUN npm install
COPY pong-client/ ./
RUN npm run build

# --- ETAPA 2: Servir con Nginx ---
FROM nginx:alpine

# Copiar tus archivos estáticos originales del frontend
COPY frontend/ /usr/share/nginx/html/
COPY public/ /usr/share/nginx/html/public/

# Copiar tu archivo de configuración de Nginx original
COPY docker/nginx.conf /etc/nginx/conf.d/default.conf

# Copiar el resultado compilado de React (Pong) a la subcarpeta /pong
COPY --from=builder /app/pong-client/dist /usr/share/nginx/html/pong

EXPOSE 80